# section 56616 Group 5 
# Deena - Khloud - Layan - Raneem - Nouf

import math
import random
import numpy as np
import matplotlib.pyplot as plt
 
def Create_Initial_Population(population_size , numOfContainers , numOfItems):
  population = []
  for i in range(population_size): 
    chromosome = [] # contains c number of containers
    for j in range(numOfItems):
      chromosome.append(np.random.randint(numOfContainers)); 
    population.append(chromosome)
  return population


def Select(population) :
  a = []
  b = []
  
  indexA = random.randrange(0,len(population)-1) ;
  indexB = random.randrange(0,len(population)-1) ;

  while indexA == indexB :
    indexB = random.randrange(0,len(population)-1) ;

  a = population[indexA] ;
  b = population[indexB] ;

  return a , b
     
def Compute_Population_Fitness(population , weights , numOfContainers , numOfItems) :
  FitnessValues = [0] * len(population)
  for i in range(len(population)) :
    sums = [0] * numOfContainers ;
    for j in range(numOfItems) :
      sums[population[i][j]] += weights[j] ;
 
    sum_diff = 0
    for p in range(numOfContainers):
      for q in range(p + 1, numOfContainers):
        sum_diff += abs(sums[p] - sums[q])
      
      FitnessValues[i] = sum_diff
 
  return sums , FitnessValues

def crossover(a , b):
  crossover_point = random.randint(1, len(a)) # chromosome lenght - 1
  #print("\nCrossover point:", crossover_point)
  for i in range(crossover_point, len(a)): 
      a[i], b[i] = b[i], a[i]
    
  return a , b

def mutate(child , c , k):

  newChild = child.copy()

  for i in range(k) :
    newChild[np.random.randint(0, len(newChild))] = np.random.randint(c)
  
  return newChild

def Compute_Chromosome_Fitness(child , weights , numOfContainers , numOfItems) :
  FitnessValue = 0
  sums = [0] * numOfContainers ;
  for i in range(numOfItems) :
    sums[child[i]] += weights[i] ;

  for p in range(numOfContainers):
    for q in range(p + 1, numOfContainers):
      FitnessValue += abs(sums[p] - sums[q])
      
  return FitnessValue

def Weak_Replacement(population , child , FitnessValues , Fitness_Value_child) :
  WorstValue = -1 # max diff value
  WorstIndex = -1

  for i in range(len(FitnessValues)) :
    if FitnessValues[i] > WorstValue :
      WorstValue = FitnessValues[i]
      WorstIndex = i
  
  if WorstValue > Fitness_Value_child :
    population[WorstIndex] = child
    FitnessValues[WorstIndex] = Fitness_Value_child
  elif WorstValue == Fitness_Value_child :
    if(random.randint(0 , 2) == 0) :
      population[WorstIndex] = child
      FitnessValues[WorstIndex] = Fitness_Value_child

  return population , FitnessValues

def Termination():
  if (number_of_generation > 10000): #max generation is 10000
      return False
  else:
      return True

def graph(number_of_generation, fitness_per_generation):
  x = np.arange(1, number_of_generation)
  y = fitness_per_generation
  plt.plot(x, y, )
  plt.xlabel("Generation")
  plt.ylabel("Fitness")
  plt.title("GA Performance")
  plt.show()

##################### START #####################  
 
c = input("Enter number of containers: ")
n = input("Enter number of items: ")
 
option = input("Enter 1 for Option 1 (i / 2) or 2 for Option 2 (i^2/2): ")
 
weights = []
 
if option == "1": 
  for i in range(1, int(n) + 1) :
    weights.append(i / 2)    
else:
  for i in range(1, int(n) + 1) :
    weights.append(i**2 / 2)
    
# create a population
population = Create_Initial_Population(10 , int(c) , int(n))
#print("\nInitial population : ")
#print(population)

#----------------------

# Compute fitness for population
sums , FitnessValues = Compute_Population_Fitness(population , weights, int(c) , int(n))
#print("\nFitness values for each chromosoum in the population : ")
# #print(sums) 
#print(FitnessValues)

normalized_array = [] 
fitness_per_generation = []
number_of_generation = 1

 
while(Termination()):

  #print("\nFitness values for each chromosoum in the population : ")
  #print(sums) 
  #print(FitnessValues)

  #Calculating averge fitness
  average_fitness = sum(FitnessValues) / len(FitnessValues)
  fitness_per_generation.append(average_fitness)
    
  #----------------------

  #Select a parents
  a , b = Select(population)
  #print("\nGeneration #", number_of_generation)
  #print("\nThe selected parents are  : ")
  #print("parent a : ", a)
  #print("parent b : ", b)

  #----------------------

  #Generated children after crossover
  e , f = crossover(a , b)
  #print("\nThe generated children after crossover  : ")
  #print("child e : ", e)
  #print("child f : ", f)

  #----------------------

  #Generated children after mutation
  k = 5
  u = mutate(e , int(c) , k)
  v = mutate(f , int(c) , k)
  #print("\nThe children after mutation  : ")
  #print("child u : ", u)
  #print("child v : ", v)

  #----------------------

  # Compute fitness for u & v
  Fitness_Value_u = Compute_Chromosome_Fitness(u , weights, int(c) , int(n))
  Fitness_Value_v = Compute_Chromosome_Fitness(v , weights, int(c) , int(n))
  #print("\nFitness values for u : ")
  #print(Fitness_Value_u)
  #print("\nFitness values for v : ")
  #print(Fitness_Value_v)

  #----------------------

  # Weak replacement for u & v
  population , FitnessValues = Weak_Replacement(population , u , FitnessValues , Fitness_Value_u)
  #print("\nPopulation after weak replacement with u: ")
  #print(population)
  population , FitnessValues = Weak_Replacement(population , v , FitnessValues , Fitness_Value_v)
  #print("\nPopulation after weak replacement with v: ")
  #print(population)

  #----------------------

  number_of_generation += 1

print("\nGeneration #", number_of_generation-1)

#Normalization
data = np.array(fitness_per_generation)
data_norm = (data - data.min())/ (data.max() - data.min())
normalized_array = [item * 100 for item in data_norm]

#Result
graph(number_of_generation, fitness_per_generation)
graph(number_of_generation, normalized_array)